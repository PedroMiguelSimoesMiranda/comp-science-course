package poo;

public class OrderedIterator extends AbstractIterator{

	public OrderedIterator(PlayList pl) {
		super(pl);
	
	}

}
