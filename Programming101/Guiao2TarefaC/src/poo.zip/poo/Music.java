package poo;

public class Music {

}
