package poo;

public class StraightforwardIterator extends AbstractIterator {

	public StraightforwardIterator(PlayList pl) {
		super(pl);
	}
	
	

}
