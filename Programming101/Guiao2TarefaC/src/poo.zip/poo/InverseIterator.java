package poo;

public class InverseIterator {

}
