package poo;

public class AbstractIterator {
	
	public AbstractIterator(PlayList pl) {
		_playList = pl;
		}
	
		public abstract boolean hasNext();
	
		public abstract Music next();

}
