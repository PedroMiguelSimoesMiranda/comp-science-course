package poo;

public class Grade {

	private int grade;
	private int naluno;

	Grade(int num,int grad){
		naluno=num;	
		grade=grad;
	}

	public int getGrade(){
		return grade;
	}

	public int getNAluno(){
		return naluno;
	}

}
