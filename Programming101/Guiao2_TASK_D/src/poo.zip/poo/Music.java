package poo;

public class Music implements Comparable<Music>{
	
//	Constantes
	public static final int FORMAT_AIFF=2;
	public static final int FORMAT_MP3=4;
	public static final int FORMAT_WAV=6;
	public static final int MINIMUM_RATING=1;
	public static final int MAXIMUM_RATING=5;


	//Variáveis
	private String musicName;
	private String artistName;
	private int duration;
	private int mformat;
	private int rating;



	//Construtor
	public Music(String name,String artist,int duration,int format,int rating){
		this(name);
		this.artistName=artist;
		this.duration=duration;
		if(format>MAXIMUM_RATING){
		format=MAXIMUM_RATING;
		}
		else if(format<MINIMUM_RATING){
		format=MINIMUM_RATING;	
		}
		else 
			this.mformat=format;
		this.rating=rating;	
	}

	public Music(String name){
		this.musicName=name;
		
	}


	//M�todos
	public String getName(){
		return musicName;
	}

	public String getArtist(){
		return artistName;
	}

	public int getDuration(){
		return duration;
	}

	public int getFormat(){
		return mformat;
	}

	public int getRating(){
		return rating;
	}


	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Music other = (Music) obj;
		if (artistName == null) {
			if (other.artistName != null)
				return false;
		} else if (!artistName.equals(other.artistName))
			return false;
		if (duration != other.duration)
			return false;
		if (musicName == null) {
			if (other.musicName != null)
				return false;
		} else if (!musicName.equals(other.musicName))
			return false;
		if (rating != other.rating)
			return false;
		return true;
	}

	public Music convert(int fileFormat){
		Music m = new Music(musicName,artistName,duration,fileFormat,rating);
		return m;	
	}
	
	@Override
	public int compareTo(Music m) {
		return musicName.compareTo(m.getName());
	}

}

